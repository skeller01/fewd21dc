jqBootstapValidation
====================

A JQuery validation framework for bootstrap forms.

Displays validation errors in `help-block` elements as users type.

More information is available at http://ReactiveRaven.github.com/jqBootstrapValidation

Changes
=======

1.3.2 - Patch for infinite-loop/slow-script-warning in IE8 - thanks to @dangerbell
